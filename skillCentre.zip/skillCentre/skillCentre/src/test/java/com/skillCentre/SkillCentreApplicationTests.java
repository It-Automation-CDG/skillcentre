package com.skillCentre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillCentreApplicationTests {

	@Test
	void contextLoads() {
	}

}
